export interface CepData {
    erro: any;
    dsCep: string;
    dsLogradouro: string;
    dsBairro: string;
    dsEstado: string;
    nrDdd: string;
  }
  