export interface Login{
    ds_Nome?: String,
    ds_Cpf: String,
    ds_Senha: String
  }
