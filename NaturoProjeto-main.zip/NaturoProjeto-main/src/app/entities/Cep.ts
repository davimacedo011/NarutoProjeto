export interface Cep {
  dsCep?: string;
  dsLogradouro: string;
  dsBairro: string;
  dsEstado: string;
  nrDdd?: number;
}
