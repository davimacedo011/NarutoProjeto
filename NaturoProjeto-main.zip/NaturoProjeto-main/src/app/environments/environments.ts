export const environment = {
    production: false,
    baseUrlCep: 'http://localhost:8080/principal',
    baseUrlLogin: 'http://localhost:8080/api/login'
};